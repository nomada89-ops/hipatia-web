'use client';

import InverterDashboard from './solar/inverters/page';

export default function Home() {
  return <InverterDashboard />;
}
